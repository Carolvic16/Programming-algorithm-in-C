#include <stdio.h>
#include <stdlib.h>
int main  (){

    float n1;
    float n2;
    float res;
    char opc;

    printf("N1:\n");
    scanf("%f", &n1);

    printf("N2:\n");
    scanf("%f", &n2);

    printf("Escolha uma operação de acordo com o menu:\n");
    printf("   +)Adicao;\n");
    printf("   -)Subtracao;\n");
    printf("   *) Multiplicacao;\n");
    printf("   /)Divisao;\n");
    printf("Operacao:");
    scanf(" %c", &opc);

switch( opc ){
    case '+':
    res = n1 + n2;
    printf("%.2f + %.2f = %.2f", n1,n2,res);
    break;

    case '-':
    res = n1 - n2;
    printf("%.2f - %.2f = %.2f", n1,n2,res);
    break;

    case '*':
    res = n1 * n2;
    printf("%.2f * %.2f = %.2f", n1,n2,res);
    break;

    case '/':
    res = n1 / n2;
    printf("%.2f / %.2f = %.2f", n1,n2,res);
    break;

    default:
    printf("Opcao invalida!");
    break;
}



    return 0;
}